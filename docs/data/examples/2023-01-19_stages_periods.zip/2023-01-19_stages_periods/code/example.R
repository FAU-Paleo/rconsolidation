# setting a working directory
setwd("C:/Examples/2023-01-19_stages_periods")

# Read in the file
stages <- read.csv("data/stages.csv")

# Get the post paleozoic part of the object
postPaleo <- stages[ 52<=stages$stg , ]

# get all the different systems/periods once
periods <- unique(postPaleo$system)

# the final result, a container in the for loop
durations <- NULL

# iteration for evvery period/system
for(current in periods){
  # the subset of the table that corresponds to the current system
  curTab <- postPaleo[ current == postPaleo$system, ]

  # calculate duration and save it
  durations <- c(durations, sum(curTab$dur))
}

# assigning names to the values
names(durations) <- periods

# final result
durations

# Plot a histogram of the durations! You can do this by putting the result of of step 4 into the hist() function!
hist(durations)
