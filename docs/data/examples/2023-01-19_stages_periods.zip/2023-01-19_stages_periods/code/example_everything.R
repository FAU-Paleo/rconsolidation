setwd("C:/Examples/2023-01-19_stages_periods")

# Read it into R with read.csv()
stages <- read.csv("data/stages.csv")
str(stages)

# Subset to Mesozoic + Cenozoic!
52<=stages$stg

# object [rows, columns]
postPaleo <- stages[ 52<=stages$stg , ]

#stages[ 52<=stages$stg , 1 ]
#stages[ 52<=stages$stg , 1:4 ]
#stages[ 52<=stages$stg , "series" ]

# Calculate the duration of every System/Period! You can do this with a for() loop. The duration of a period is the difference between the older boundary of its first stage and the younger boundary of its last stage.

# 1 particular element

postPaleo[1:7, ]
postPaleo[8:18, ]

current <- "Cretaceous"

stages$mid
postPaleo$mid

postPaleo$short

# a vector vs a single value
postPaleo$system == current

# single value vs vector
# postPaleo <- stages[ 52<=stages$stg , ]

curTab <- postPaleo[ current == postPaleo$system, ]

# sum the durations
curTab[ , "dur" ] # matrix-style subsetting
curTab$dur # list-style subsetting

sum(curTab$dur)

# first bottom - last top
curTab[1 , "bottom"]
curTab$bottom[1]

# nrow(curTab)
curTab[ nrow(curTab), "top" ]
curTab$top[length(curTab$top)]
# curTab[12, "top"]

# first - last
curTab[1 , "bottom"] - curTab$top[length(curTab$top)]

# "Triassic"==current
# "Jurassic"==current
# "Cretaceous"==current

# 2. do the iteratio
current <- "Triassic"
curTab <- postPaleo[ current == postPaleo$system, ]
sum(curTab$dur)

current <- "Jurassic"
curTab <- postPaleo[ current == postPaleo$system, ]
sum(curTab$dur)

current <- "Neogene"
curTab <- postPaleo[ current == postPaleo$system, ]
sum(curTab$dur)

# postPaleo$system

periods <- unique(postPaleo$system)
durations <- NULL
# durations <- c()

for(current in periods){
  #  message(current)
  curTab <- postPaleo[ current == postPaleo$system, ]
  #  message(sum(curTab$dur))
  durations <- c(durations, sum(curTab$dur))
}

names(durations) <- periods
names(durations)

# Plot a histogram of the durations! You can do this by putting the result of of step 4 into the hist() function!

