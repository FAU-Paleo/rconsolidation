# Example exercise
# 2023-10-24

# read in the data file
stages <- read.csv("C:/Users/Adam/Desktop/2023-2024winter/rconsolidation/lecture_2/data/stages.csv")

# afterwards always check for structure
str(stages)

# str also tells you the class
class(stages)
typeof(stages) # the $ in str() tells you that you actually deal with a list!!
View(stages) # data.frame as a tabular format


# subset to mesozoic and cenozoic

# Identify the rows that we need. First, do this 'manually' in your mind.!
# Mesozoic starts with the Triassic. We need data from the first row of the Triassic, 
# and everything after that. 

# Need to extract from a data frame:
# object name + square brackets
# stages[]

# 2 dimensions, need a comma (rows, columns)
# stages[, ]

# directly! hard-coding values, first row of Triassic, last row of the Table
stages[52:95, ]

# somewhat better, first row of the Triassic, last row of the table (procedurally!)
stages[52:nrow(stages), ]

# First row of the Triassic: procedurally?
# which rows correspond to the Triassic?
which(stages$system=="Triassic")

# Which is the first row of the Triassic? (Implying that rows are ordered!)
# min(which(stages$system=="Triassic"))

# from first value of the Triassic to the last of the table
stages[min(which(stages$system=="Triassic")):nrow(stages), ]



# 4. The durations of the periods
# I. First, solve for one period "Permian"
# II. Solve for all periods, based on I. 

# I. For the Permian
# define the rows of the period -> calculate the row indices
# where?
stages$system

# The Permian rows
stages$system=="Permian"

# row indices of the Permian
which(stages$system=="Permian")

# extract the corresponding durations
systemDurations <- stages$dur[which(stages$system=="Permian")]

# sum them up
sum(systemDurations)



# II. Solve for all periods
# Same code. What should change in every iteration? The system name. 
# The same calculations for the Triassic:

# extract the corresponding durations
systemDurations <- stages$dur[which(stages$system=="Triassic")]

# sum them up
sum(systemDurations)

###############

# What needs to change: make it a variable eg.
changeSystem <- "Triassic"

# extract the corresponding durations
systemDurations <- stages$dur[which(stages$system==changeSystem)]

# sum them up
sum(systemDurations)


##############
# Define the loop afterwards

# 1. OBJECT TO DEFINE LOOP: the set of all systems
sysSet <- unique(stages$system)

# 2. OBJECT TO STORE THE RESULTS placeholder
container <- rep(NA, length(stageSet))


# 3. LOOP DEFINTION (integer sequence along the set)
for(i in 1:length(sysSet)){
  
  # the system changes in every repetition
  # 4. ENSURE THAT THE INSTRUCTIONS CHANGE IN THE LOOP 
  changeSystem <- sysSet[i]
  
  # the same calculations earlier
  systemDurations <- stages$dur[which(stages$system==changeSystem)]

  # sum them up, put into the corresponding vector
  container[i] <- sum(systemDurations)
}

# add names to the container to make it 
names(container) <- sysSet

