# Operators and types 

# !logical
!TRUE

# !numeric
!4
!0

# !character: ERROR
!"a"

# logical == logical
TRUE==TRUE

# numeric == numeric
4==5
4==4

# character == character
"a" == "badf"
"a" == "a"

# logical == numeric
4 == TRUE

# numeric == character
4 == "4"
"5" == 3

# character == logical
"A" == TRUE

# > 

# logical >  logical 
TRUE > TRUE
# numeric > numeric 
23 > 4

# character > character 
"b" > "a"
"b" < "a"
"A"> "a"
"b"< "A"
"a" > 4


# logical | logical 
TRUE| FALSE

# numeric | nueric 
4| 9

# character | character -> ERROR 
"a" | "io"

# numeric | character -> ERROR 
45 | "a"


# logical + logical
TRUE + TRUE

# numeric + numeric
4 + 4

# character + character -> ERROR
"a" + "b"

# logical + numeric
TRUE + 67

# character + numeric -> ERROR
"a" + 4

# logical%%logical
TRUE %% TRUE

# numeric%%numeric
45%%67

# character%%character -> ERROR
"45" %% "df"

# logical%%numeric
TRUE %% 23

# character%%numeric -> ERROR
"asdf" %% 34

################################################################################
#Type detection

# 12
typeof(12)
is.double(12)

# Use this!
is.numeric(12)


# 5L
is.integer(5L)
is.numeric(5L)
is.double(5L)


# "TRUE"
typeof("TRUE")
is.character("TRUE")
is.logical("TRUE")

# 3.4e10 
typeof(3.4e10)
is.numeric(3.4e10)
is.integer(3.4e10)
# larger numbers
3.4e10 == 3.4 * 10^10


# 33+1i 
typeof(33+1i)

# complex is not numeric
is.numeric(33+1i) 
is.complex(33+1i)

# typeof(typeof(0))
typeof(typeof(typeof(typeof(0))))

