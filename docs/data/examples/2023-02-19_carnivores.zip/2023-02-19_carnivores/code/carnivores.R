setwd("/home/adam/Desktop/2023-02-19_carnivores/")

# read the data
carnivores <- read.csv("data/carnivore_families.csv")

# 3 the unique families
fam <- unique(carnivores$family)

# 4a. omit where family is ""! -> list of symbols
# : colon
# { curly braces
# [ square brackets
# ( parenthesis
# <- assignemnt
# < chevron
# - dash
# " double quotes

# Bastian's original solution:
dataFix1 <- carnivores[""!=carnivores$family, ]
# there are no NAs in the dataset
sum(is.na(carnivores$family))


##################################
# interlude  about missing values

# Sometimes the solution from above does not work this good, because there are missing entries in the data

# insert one missing value
carnivores$family[1] <- NA

# it is detectable
sum(is.na(carnivores$family))

# if you use the logical subscript, i will conserve the NA
dataFixNA <- carnivores[""!=carnivores$family, ]

# proof that there is a missing value 
sum(is.na(dataFixNA$family))

# the reason: WHen NAs are used in subscripts, they will enforce the insertion of
# missing entries, values or rows
# no misssing values
carnivores[1:3, ]

# entire row of missing values
carnivores[c(1,2,NA), ]

# solution: use which() around the logical subscript. 
# this will omit the missing entries and returns the index of those entries, where the value is TRUE
dataFixNA <- carnivores[which(""!=carnivores$family), ]

# no NAs now!
sum(is.na(dataFixNA$family))

# revert the carniovers object
carnivores <- read.csv("data/carnivore_families.csv")

# end of interlude...
##################################

# the same but with thich
dataFix1 <- carnivores[which(""!=carnivores$family), ]

# entry now gone
unique(dataFix1$family)

# 4b. family is "NO_FAMILY_SPECIFIED"
dataFix2 <- dataFix1[which("NO_FAMILY_SPECIFIED"!=dataFix1$family), ]
unique(dataFix2$family)

# 4c.  genus is ""
dataClean <- dataFix2[which(""!=dataFix2$genus), ]
unique(dataClean$genus)

# dataClean is the cleaned data file

# 5. Subset your data to the family "Canidae".
canidae <- dataClean[which("Canidae"==dataClean$family), ]

# count the number of genera ($genus)
# na.omit() is not necessary, but it is not bad,
# it will omit the missing values from the vector
length(unique(na.omit(canidae$genus)))

# 6. Make sure that the unique list of families do not contain the bad entries! Using a for loop, repeat step 5 and count the number of genera for every family!
fam <- unique(dataClean$family)

# empty container
gen <- c()

# loop through the  families
for(i in 1:length(fam)){
    # focusing on one family
    currentFam <- fam[i]

    # data corresponding to the focus-family
    familySub <- dataClean[which(dataClean$family==currentFam),]

    # the number of genera in the current family
    famGen <- length(unique(na.omit(familySub$genus)))

    # add it to the rest
    gen <- c(gen, famGen)

    # add the name of the family
    names(gen)[length(gen)] <- currentFam

}

# 7. Histogram. exponential-like distribution
hist(gen)

# 8. median
median(gen)

# 8. Which family has the highest number of genera? What is the median number of genera in a family?
# largest value
max(gen)

# named value, return original data where it is maximum
gen[max(gen)==gen]

# Only the name 
names(gen)[which(max(gen)==gen)]

# Mentioning missing laues again
# what if one of the values were missing value? 
# if there are missing values
gen[1] <- NA

# All missing: max(gen) is NA
names(gen)[max(gen)==gen]

# One extra missing value - as above! 
names(gen)[max(gen, na.rm=T)==gen]

# which() fixes this - best solution
names(gen)[which(max(gen, na.rm=T)==gen)]


