setwd("/mnt/sky/Dropbox/Teaching/FAU/RConsolidation/2026/2026-10-26/2023-01-17_favia-occurrencecount/")

# 2. Read in the data
favia <- read.csv("data/favia.csv")

# check the structure! it looks ok
str(favia)

# 3. Calculate how many occurrences (rows in the table) the genus has where the stg (stage) column’s value is 87!
# This indicates Priabonian (Eocene) stage. This should be a single numeric value.

# dataset corresponding to stage 87
faviaDat<- favia[which(favia$stg==87), ]

# the number of occurrences from here is
nrow(faviaDat)

# alternatively, access a specific column and get its length
length(favia[which(favia$stg==87), "genus"])

################################################################################
# note about the subset() function
################################################################################
# this is used sometimes, and gives the same result as: faviaDat$genus
subset(favia, stg==87, select=genus)

# I do not recommend using this function, because it can have some issues -> check out ?subset and search for 'warning'
# The non-standard evaluation means that this cannot be evalulated on its own
#     stg==87 # gives an error
# and neither can this:
#    select=genus
# 'genus' appears to be symbol, but it is actually not, so the syntax becomes very confusing

# Follwoing R's rules this statments shoudl be identical with favia$early_interval, but is is not
stg <- "early_interval"
subset(favia, select=stg)

# stg is forced to become a column name, even when it is explicitly defined to be a variable. This is much cleaner
stg <- "early_interval"

# compare
favia[, stg]
favia[, "stg"]
################################################################################

# 4. Calculate how many different collections (entries in the collection_no column) there are in this stage!
# This should be a single numeric value.
unColls <- unique(faviaDat[, "collection_no"])
length(unColls)

# alternatively
length(table(faviaDat[, "collection_no"]))

# 5. Calculate which stg numbers does this genus occur in! This should be a numeric vector.
unique(favia$stg)

# you can also sort these
sort(unique(favia$stg))

# this is a bit contorted but also fine
as.numeric(names(table(favia$stg)))

# 6. Calculate the number of occurrences and collections in every stage! These should be two numeric vectors.
# Please indicate which stages the values in these vectors refer to by adding the stg numbers as the names attribute!

# 1. With for loop

# we have to iterate this for ever stg that we have
guide <- sort(unique(favia$stg))

# create containers
# occurrences
nOccs <- rep(NA, length(guide))
names(nOccs) <- guide
# collections
nColls <- rep(NA, length(guide))
names(nColls) <- guide

# for loop
# check with i <- 10 for example!
for(i in 1:length(guide)){
	# the focal stage
	focalStg <- guide[i]

	# isolate the subset
	stgDat<- favia[which(favia$stg==focalStg), ]

	# the number of occurrences
	nOccs[i] <- nrow(stgDat)

	# the number of collections
	nColls[i] <- length(table(stgDat$collection_no))
	
}

# the two results are
nOccs
nColls

# 6b. Functionally

# the number of occurrences is very easy, this you can do with the table function
table(favia$stg)

# the number of collections
# unique stg and collection_no combinations
stgColl <- unique(favia[, c("stg", "collection_no")])

# the number of collections in a stage is
table(stgColl$stg)

# but! this solution counts the missing value as a collection_no in stg 95!
