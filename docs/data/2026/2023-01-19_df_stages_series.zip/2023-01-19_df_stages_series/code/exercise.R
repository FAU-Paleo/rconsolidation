# working directory
setwd("/home/adam/Desktop/rconsolidation/2026-10-12/2023-01-19_df_stages_series")

# 2. read in the files
stages <- read.csv("data/stages.csv")
str(stages)

# 3. Remove the first three rows
# Both works
phan <- stages[-(1:3), ]
phan <- stages[which(stages$system!="Ediacaran"), ] 

#-(1:3)
# -1:-3

# 4. The Jurassic subset
jur <- stages[which(stages$system=="Jurassic"), ]

# the number of series
length(unique(jur$series))

# 5. A list of all the periods
unisys <- unique(stages$system)

# 6. The number series/epochs in every period.
# create a container to store the results
seriesCount <- rep(NA, length(unisys))

# indiciate which value belongs to which series
names(seriesCount) <- unisys

for(i in 1:length(unisys)){
	# message indicating the start
	message(i)

	# focal system
	focal <- unisys[i]

	# subset of a system
	sys <- stages[which(stages$system==focal), ]

	# the result of iteration
	res <- length(table(sys$series))

	# store
	seriesCount[i] <- res

}

