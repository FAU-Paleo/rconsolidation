#  Carnivore genera in the Paleobiology Database 
# 2026-10-26
# Set the working directory
setwd("C:/Users/Adam/Desktop/rconsolidation/2026-10-26/2023-02-19_carnivores_pbdb")

# read in the data 
carnivora <- read.csv("data/carnivore_families.csv")

# the number of families:
# This is the raw number of entries in the column.
# this might have missing values in it
length(unique(carnivora$family))

# this cannot have missing values!
length(table(carnivora$family))

# there are some bogus entries, though, which you might need to omit
allFam <- unique(carnivora$family)
allFam

# omitting these cann be done with either
allFam[which(allFam !="" & allFam !="NO_FAMILY_SPECIFIED")]
allFam[which(!(allFam =="" | allFam =="NO_FAMILY_SPECIFIED"))]
allFam[!allFam %in% c("", "NO_FAMILY_SPECIFIED")]

# the total number of real family entries
length(allFam[!allFam %in% c("", "NO_FAMILY_SPECIFIED")])

# 4. getting rid of wrong entries from family and genus columns
clean <- carnivora[which(carnivora$family!="" & 
  carnivora$family!="NO_FAMILY_SPECIFIED" & 
  carnivora$genus!=""),]

# 5. subsetting Canidae
canidae <- clean[which(clean$family=="Canidae"),]

# length(unique()) can have missing
length(unique(canidae$genus))

# these ones can't
length(table(canidae$genus))
length(levels(factor(canidae$genus)))

# 6. Get a clean list of families
# We will use iteration for the total dataset
famList <- unique(clean$family)

# container - pre-allocated values for every genus
nGenera <- rep(NA, length(famList))
names(nGenera) <- famList

# write a loop across all families
# 1. iteration using integers 
for(i in 1:length(famList)){
  # get the name from the list of families
  focalFamily <- famList[i]
  
  # the data corresponding to the name 
  focalData <- clean[which(clean$family==focalFamily), ]
  
  # counting the number of genera, using the integer index
  # to store the result
  nGenera[i]<-length(table(focalData$genus))
  
}

# 7. Histogram
hist(nGenera, breaks=20)

# 8. Family with the highest number of genera
# single which max
names(which.max(nGenera))
# which + max
names(which(max(nGenera)==nGenera))

# logical subsetting on the name
names(nGenera)[which(max(nGenera)==nGenera)]




# Iteration differently
famList <- unique(clean$family)

# aggregating container: this is better, when you don't know
# how many values you will have in the end!
nGenera <- c()
nGenera <- NULL

# write a loop across all families
for(i in 1:length(famList)){
  
  # same as above
  focalFamily <- famList[i]
  
  # same as above
  focalData <- clean[which(clean$family==focalFamily), ]
 
  # aggregate with c
  nGenera <- c(nGenera, length(table(focalData$genus)))
  
}

names(nGenera) <- famList


# Solution 3

# container
nGenera <- c()
nGenera <- NULL

# write a loop across all families
# using the family list as a guide
# somewhat less flexible, but just as fine
# i will not be a number, it will be a family name
for(i in famList){
  
  # if you need the number of the toop
  number <- which(i==famList)
  message(number)
  
  # you can use i here directly!
  focalData <- clean[which(clean$family==i), ]
  
  # and then count
  nGenera <- c(nGenera, length(table(focalData$genus)))
  
}

