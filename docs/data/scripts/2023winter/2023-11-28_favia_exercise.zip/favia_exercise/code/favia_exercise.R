#
setwd("C:/Users/Adam/Desktop/2023-2024winter/rconsolidation/lecture_7/favia_exercise")

# 2. import the data file
favia <- read.csv("data/favia.csv")
# check structure!
str(favia)

# number of occurrences/number of rows in stg 87
# logical vector where stg is equal to 87
favia$stg==87

# solution 1
sum(favia$stg==87)

# solution 2
length(which(favia$stg==87))

# solution 3
tab <- table(favia$stg)
str(tab)
typeof(tab)
class(tab)

# names, colnames, rownames, dimnames
# what value is called "87"
# character subscript
tab["87"]

# VERY DIFFERENT FROM: what is the 87th value
# numeric subscript
tab[87]

# 4. number of different collections in stg 87
# solution 1 
length(unique(favia$collection_no[which(favia$stg==87)]))

# stage-specific data frame
# solution 2 
stgDat <- favia[which(favia$stg==87), ]
length(unique(stgDat$collection_no))

# idiom: subsetting column (stg, collection_no), unique,table, subscript
lookup <- unique(favia[, c("stg", "collection_no")])
table(lookup$stg)["87"]

# 5. the different stg values
unique(favia$stg)
# sort(unique(favia$stg))
# as.numeric(names(table(favia$stg)))

# 6. iterate for all stages

# what we want to iterate
# number of occurrences
sum(favia$stg==87)
# number of colletion
length(unique(favia$collection_no[which(favia$stg==85)]))

# setup:
# guiding vector, what the iteration is based on
# you will do one loop for every value
allStages <- sort(unique(favia$stg))

# containers to store the results
occurrences <- rep(NA, length(allStages))
collections <- rep(NA, length(allStages))

# add names so the results are tied to the stages
# in the object structure
names(occurrences) <- allStages
names(collections) <- allStages

# definition of the loop
for(i in 1:length(allStages)){
  # the current focal stage
  current <- allStages[i]
  # current <- 86 # what we practiced with 
  # number of occurrences
  occurrences[i] <- sum(favia$stg==current)
  # number of collection
  collections[i] <- length(unique(favia$collection_no[which(favia$stg==current)]))
}

# direct access
occurrences["91"]

# implied connection
occurrences[allStages==91]

# number of occurrences
occurrences
table(favia$stg)

# number of collections
collections

# same as earlier!
lookup <- unique(favia[, c("stg", "collection_no")])
table(lookup$stg)

