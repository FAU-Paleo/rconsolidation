# Working with the coin flip exercise

# working directory
setwd("/mnt/sky/Dropbox/Teaching/FAU/RConsolidation/2023/lecture_11/coins/")

# Readin in the mentally simulated coin flips.
# Adam's coin flips
coins <- read.csv("data/coins.txt", header=FALSE)

# number of rows 
length(coins)
length(coins[,1])
length(coins$V1)

########################################----------------------------------------
# 1. Number of Tails or Heads:
# length - which - logical
length(which(coins$V1=="H"))

# sum -logical
sum(coins$V1=="T")

# both
table(coins$V1)

########################################----------------------------------------
# Artificially generating this
# different every time
sample(c("T", "H"), 200, replace=TRUE)
sample(c("T", "H"), 200, replace=TRUE)

# The number of heads tails every time -> according to a pattern
trial <- sample(c("T", "H"), 200, replace=TRUE)
table(trial)["H"]


# Let's repeat the random generation lots of times, to see whether there is a pattern!
# number of samples 
n <- 10000

# storage container for results
heads <- rep(NA, n)

# repeat for every sample
for(i in 1:n){
	# random sample 
	trial <- sample(c("T", "H"), 200, replace=TRUE)
	# calculate the number of heads and store
	heads[i] <- table(trial)["H"]
}

# tabulate the number of heads in every 200 coin toss!
table(heads)

# experiment with setting n to 100, 1000 and 10000!
plot(table(heads))

# as n increases, the shape of the result becomes
# - smoother
# - more stable
# which suggests that the pattern approaches a theoretical limit

# Probability theory tells us what this is like when the number of samples approach infinity.
# (the law of large numbers)

# with a smaller size/number of tosses
trial <- sample(c("T", "H"), 10, replace=TRUE)
table(trial)
# experiment with the code above with setting the sample size
# from 200 to 10!

# the dbinom() function: from Density BINOMial  
# what is the probability of getting
# - EXACTLY 5 successes (heads)
# - out of 10 trials (tosses)
# - with a probability of 0.5 (fair coin)
dbinom(5, 10, prob=0.5)

# the number of trials (coin tosses) 
size <-200

# calculate for every possible number of successes
# The binomial is a discrete distribution
# (you cannot have 1.5 heads from 10 tosses!)
# so this the Probability Mass Function (PMF,
# we use density for continuous functions: PDFs)
# 0 success to all successes
density <- dbinom(0:size, size, prob=0.01)

# the vaules here add up to exactly 1
sum(density)

# visualize the values 
plot(0:size,density, type="h" )

# A. experiment with setting size to 10, 100, 1000, 10000!
# As the number increases, the bell-shape will become smaller, but also smoother!
# As size approaches infinity, we approximate the Gaussian or Normal distribution.

# B. experiment with setting the probability something else, like 0.1!
# notice how the distribution's shape changes!

################################################################################
# Continue from here on 2024-01-26

# 1. Estimates
table(coins$V1)["H"]/sum(table(coins$V1))

# Inference is about figuring out what the probability of the coin flip is,
# from the heads and the tails.

# The exact probability (b) that you get 88 Heads out of 200 trials if the probability
# of heads is p is given by these:
b <- dbinom(88, 200, p=0.5)
b <- dbinom(88, 200, p=0.6)
b <- dbinom(88, 200, p=0.4)

# Among these, it is actually highest with 0.4. You can calculate this 'b' probability
# for every possible values of p [0,1]! This is called the likelihood.

# Challenge:
# Write a for loop to calculate these probabilities for this sequence: seq(0,1,0.01)!
# And plot it!

# The highest probability (p) is actually given for 88/200:
b <- dbinom(88, 200, p=88/200)
b

# This is called the maximum likelihood estimate for the probability of the individual toss.
# This however does prove that the coin is not fair! It might be just 'sampling noise'
# that we do not actually see 0.5 as the most likely probability!

# 2. Statistical hypothesis testing

# We can be fairly convinced that the coin is actually fair. This can be expressed as a hypothesis,
# a statement about reality that is either true or false. e.g.
# The true probability of the coin toss result is not 0.5. 
# Our baseline expectation is that the coin is fair. This is the null hypothesis (H0).
# In scientific contexts, the null hypothesis typically represents the expectations
# under our current knowledge basis. If this is disproven (falsified) then we can be
# fairly certain that we have acquired new knowledge.

# Null hypotheses are complimented by alternative hypotheses (H1). In this case the alternative hypothesis
# can be that the coin is NOT FAIR. 

# We can run a binomial test using the data of our hypothesis test. This test will provide information
# on whether we better reject the null or the alternative hypothesis.
binom.test(88, 200, p=0.5)

# This call provides us with the transation of our alternative hypothesis:
# true probability of success is not equal to 0.5

# The call gives us a confidence interval for our estimate of the p probability (this is based on the likelihoods).
# The 95 percent confidence interval indicates that based on the 88 successes from the 200 trials, there is a 95%
# chance that the true probability is in the  0.3700556 0.5117497 range. The sample estimate gives us the most likely estimate:
# where the likelihood function is highest.

# The key bit in this framework (the 'frequentist' approach) is the so called p-value, which in our case is 0.1036. This is a relatively high p-value.
# The p-value means that if we reject the null hypothesis (so we accept that the coin is not fair), there is a ~10% chance
# that we will make a mistake (called a Type I error). In simplified words, this means that there is a 10% chance that the null model
# can produce our result that we see in the sample. Since this is considerably high, we can cannot say with confidence that the coin is not fair: we have to
# reject the alternative hypothesis, and accept the null.

# Note that this is also reflected in the estimate confidence interval: 0.5 is still within this interval.

# The cut-off value for this (called alpha) is subject to debate. The conventional value has been 5% for a long time. However,
# recently there is a tendency to lower this to 0.1 - or even lower.

# You can see how the testing behaves with these different values. The farther you go from the ideal 100 successes. The lower
# the p value becomes!
binom.test(40, 200, p=0.5)
binom.test(120, 200, p=0.5)
binom.test(130, 200, p=0.5)


# the test is symmetric, it will provide identical results with k and with n-k
binom.test(88, 200, p=0.5)
binom.test(112, 200, p=0.5)

# It turns out that when it comes to the total number, Adam is not so bad at randomly simulating Heads and Tails. But it can still be seen in the sequence!





