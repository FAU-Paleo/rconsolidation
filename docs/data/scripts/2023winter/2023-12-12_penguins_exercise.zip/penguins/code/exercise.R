# solution to https://adamtkocsis.com/rkheion/Exercises/2023-02-15_penguin_species.html
# 2023-12-12
# Set working directory
setwd("/home/adam/Desktop/Rconsolidation/lecture9/penguins/")

# 2. Reading in the data
penguins <-read.csv("data/penguins.csv")

# 3. subset
# Cf: ? subset -> search for warning: don't get into the habit of using this!
# pen2009 <- subset(penguins, year=="2009")
pen2009 <- penguins[which(penguins$year==2009), ]

# 4. list of all the species
unique(pen2009$species)

# 5a. subset the 2009 data to the Gentoo penguins
gentoo2009 <- pen2009[which(pen2009$species == "Gentoo"), ] 

# directly
#gentoo2009 <- penguins[which(penguins$year == "2009" & penguins$species == "Gentoo"), ]

################################################################################
# About the medians
# returns the middle value in the order (if length is odd)
median(sample(1:5))

# In canse the length is even: returns the arithmetic mean of the two mid-values
median(sample(1:6))

# mean
x<- 1:6
mean(x)
x[1] <- -1000

# mean is highly influenced by outliers
mean(x)

# median is not
median(x)

################################################################################
# 5b. themedian bodysize
# missing values!
median(gentoo2009$body_mass_g)

# detailed
median(gentoo2009$body_mass_g[!is.na(gentoo2009$body_mass_g)])

# we used this instead
median(gentoo2009$body_mass_g, na.rm=TRUE)

# also applicable to:
mean(goentoo2009$body_mass_g, na.rm=TRUE)
sum(gentoo2009$body_mass_g, na.rm=TRUE)
max(gentoo2009$body_mass_g, na.rm=TRUE)
min(gentoo2009$body_mass_g, na.rm=TRUE)


# 6. Repeat step 5 with a for() loop, calculate the median mass of every species.
# A. with an integer sequence
# guide!
sp <- unique(pen2009$species)

# medians of the species's body size
bodySpMed <- rep(NA, length(sp))
names(bodySpMed) <- sp

# Messing up the order is not a good idea
#bodySpMed <- sample(bodySpMed)

# if you have to put things into something
# that you did not create, use character subscripts
# to insert values where the names indicate the values' positions.

# iterate along the sequence
for(i in 1:length(sp)){
	# species in the current iteration
	focal <- sp[i]

	# focal species' data from 2009
	focalData <- pen2009[which(pen2009$species == focal), ] 

	# median body size of the focal species
	bodySpMed[i] <- median(focalData$body_mass_g, na.rm=TRUE)

	# if the bodySpMed object has a messed-up sequence, you have to use this!
	# this should not happen when you derive the it
#	bodySpMed[focal] <- median(focalData$body_mass_g, na.rm=TRUE)
	
}


# same solution, but without using the integers

# contaier to store the data
bodySpMed <- rep(NA, length(sp))
names(bodySpMed) <- sp

# i is the focal species
for(i in sp){
	# focal species' data from 2009
	focalData <- pen2009[which(pen2009$species == i), ] 

	# median body size of the focal species
	bodySpMed[i] <- median(focalData$body_mass_g, na.rm=TRUE)
	
}

# dependent variable ~ independent variables
boxplot(body_mass_g ~ species, data=pen2009)

# this is the same - but it will be uglier by default
boxplot(pen2009$body_mass_g ~ pen2009$species)

# a single variable
boxplot(gentoo2009$body_mass_g)

# getting the quantiles 
quantile(gentoo2009$body_mass_g, 0.25, na.rm=TRUE)
quantile(gentoo2009$body_mass_g, 0.75, na.rm=TRUE)
quantile(gentoo2009$body_mass_g, 0.5, na.rm=TRUE)


