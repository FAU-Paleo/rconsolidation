# A code file solution to 
# https://adamtkocsis.com/rkheion/Exercises/2023-02-19_carnivores_pbdb.html

# set working directory
setwd("/home/adam/Desktop/2024-01-30_carnivores/")

# check what the current working directory is
getwd()
# list out files in the working directory
list.files()

# list out files in the directory given here as either
# relative or absolute path
list.files("data")

########################################----------------------------------------
# 2. read in the data
car <- read.csv("data/carnivore_families.csv")
str(car)

########################################----------------------------------------
# 3. Unique families
unique(car$family)
length(unique(car$family))-2

########################################----------------------------------------
# 4. omit the invalid families from the original data
#omit empty quote family entry
car1 <- car[which(!car$family==""), ]

# omit NO_FAMILY_SPECIFIED family entry
car2 <- car1[which(!car1$family=="NO_FAMILY_SPECIFIED"), ]

# unique family entries after that
unique(car2$genus)

# omission of artifactual genera
car3 <- car2[which(car2$genus!=""), ]

########################################----------------------------------------
# 5. Canidae
canidae <- car3[which(car3$family=="Canidae"), ]

# the unique genera
gen <- unique(canidae$genus)

# their count 
length(gen)


########################################----------------------------------------
# 6. Again creating a unique list of families
# unique families
families <- unique(car3$family)

# A. set up storage
nGen <- rep(NA, length(families))
names(nGen) <- families

# B. define the loop
for(i in 1:length(families)){

	# C. adapt the body
	focalFamily <- families[i] 

	# select the focal dataset pertaining to focalFamily
	focalData <- car3[which(car3$family==focalFamily), ]

	# unique genera
	gen <- unique(focalData$genus)
	
	# D. actually saving
	# counting the unique genera
	nGen[i] <- length(gen)
	# nGen[focalFamily] <- length(gen)
}


########################################----------------------------------------
# 7. get a histogram
hist(nGen, breaks=10)

########################################----------------------------------------
# 8. The family with the highest number genera
# "Mustelidae"
names(nGen[nGen==max(nGen)])
names(nGen)[nGen==max(nGen)]


################################################################################
# subsetting in one line
car3RE <- car[
	which(car$family!="" & car$family!="NO_FAMILY_SPECIFIED" & car$genus!=""),
]


# 6. without for loop:
# the number genera in every family
# filter subset for COUNTING
# 1. Subset to limited columns
twoColumns <- car3[, c("genus", "family")]

# 2. Uniquing
uniqueTwo <- unique(twoColumns)

# 3. Use table to count
table(uniqueTwo$family)
nGen[order(names(nGen))]
