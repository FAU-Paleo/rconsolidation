# Solutions to the exercise about the IUCN Chameleon Data 

# https://adamtkocsis.com/rkheion/Exercises/2024-01-07_iucn_chameleon_table.html

# Set up working environment
setwd("/mnt/sky/Dropbox/Teaching/FAU/RConsolidation/2023/lecture_13/2024-02-05_chameleons/")

# 2. read in the data
chameleon <- read.csv("data/chameleons.csv")
str(chameleon) # wrong structure!

# need to adjust the sep argument - this is semicolon separated!
chameleon <- read.csv("data/chameleons.csv", sep=";")
str(chameleon) # correct

# 3. only genus and bionmial
genBinom <- unique(chameleon[, c("genus", "binomial")])

# 4.
# genus
length(unique(genBinom$genus))

# species binomials
length(unique(genBinom$binomial))

# this is the same - although it assumes that the taxonomy is clean!!
nrow(genBinom)

# 5. Genus with the highest number of species
# number of species in a genus
tGenera <- table(genBinom$genus)

# which name has the highest number of species?
names(tGenera)[which(tGenera==max(tGenera))]


# 6. Scatterplot
plot(chameleon$SHAPE_Area, chameleon$SHAPE_Leng)

# the two variables SEEM correlated!
# later during the program you will learn more about correlations.
# There are hypothesis tests that you can do on these, based on frequentist statistics.
# This is the Spearman rank-order correlation test 
cor.test(chameleon$SHAPE_Area, chameleon$SHAPE_Leng, method="spearman")
# you would use this with weirdly skewed, non-normal variables, like these
# The warning message indicates that there are some ties in the data - which makes
# the test result less precise, but that is of no concern.


# The null-hypothesis of this test, is that there is no correlation.
# the p-value is very low, indicating to you that there is a very low chance that you would see such
# a correlation due to random sampling given that the true correlation is actually 0
# rho is the estimate of the Spearman rank-order correlation coefficient

# 7. Conservation status is Vulnerable
vulnerable <- chameleon[which(chameleon$category=="VU"),]

# number of species in this category
length(unique(vulnerable$binomial))

# the median area
median(vulnerable$SHAPE_Area)


# 8 repeat median shape area for all categories

# A. list out the categories
categs <- unique(chameleon$category)

# B. container to store the results
categoryAreas <- rep(NA, length(categs))
# also name the elements so we can see what is what
names(categoryAreas) <- categs


# C. loop definition
for(i in 1:length(categs)){
	# the current, focal status
	focalStatus <- categs[i]
	
	# body of the loop - from previously written code
	# I renamed 'vulnerable' to 'statusData' to make it easier
	# to understand what it is
	statusData <- chameleon[which(chameleon$category==focalStatus),]

	# the result of the calculation
	# saved to the result-container
	categoryAreas[i] <- median(statusData$SHAPE_Area)
}

# the results are here
categoryAreas

# 9. Which is the highest?
names(categoryAreas)[which(categoryAreas==max(categoryAreas))]

# The least concern category has the highest median geographic range (measures as area).
# This category is the least vulnerable of all. Geographic range is usually considered
# when the conservation status is registered. Larger geographic ranges imply lower risk
# of extinction.








