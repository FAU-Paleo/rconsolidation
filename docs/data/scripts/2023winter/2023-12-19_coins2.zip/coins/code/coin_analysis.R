# Readin in out mentally simulated coin flips.
# 2023-12-19

# working directory
setwd("/home/adam/Downloads/coins/")

# Adam's coin flips
coins <- read.csv("data/coins.txt", header=FALSE)

# number of rows 
length(coins)
length(coins[,1])
length(coins$V1)

########################################----------------------------------------
# 1. Number of Tails or Heads:
# length - which - logical
length(which(coins$V1=="H"))

# sum -logical
sum(coins$V1=="T")

# both
table(coins$V1)

########################################----------------------------------------
# Artificially generating this
# different every time
sample(c("T", "H"), 200, replace=TRUE)
sample(c("T", "H"), 200, replace=TRUE)

# The number of heads tails every time -> according to a pattern
trial <- sample(c("T", "H"), 200, replace=TRUE)
table(trial)["H"]


# Let's repeat the random generation lots of times, to see whether there is a pattern!
# number of samples 
n <- 1000

# storage container for results
heads <- rep(NA, n)

# repeat for every sample
for(i in 1:n){
	# random sample 
	trial <- sample(c("T", "H"), 200, replace=TRUE)
	# calculate the number of heads and store
	heads[i] <- table(trial)["H"]
}

# tabulate the number of heads in every 200 coin toss!
table(heads)

# experiment with setting n to 100, 1000 and 10000!
plot(table(heads))

# as n increases, the shape of the result becomes
# - smoother
# - more stable
# which suggests that the pattern approaches a theoretical limit

# Probability theory tells us what this is like when the number of samples approach infinity.
# (the law of large numbers)

# with a smaller size/number of tosses
trial <- sample(c("T", "H"), 10, replace=TRUE)
table(trial)
# experiment with the code above with setting the sample size
# from 200 to 10!

# the dbinom() function: from Density BINOMial  
# what is the probability of getting
# - EXACTLY 5 successes (heads)
# - out of 10 trials (tosses)
# - with a probability of 0.5 (fair coin)
dbinom(5, 10, prob=0.5)

# the number of trials (coin tosses) 
size <-500

# calculate for every possible number of successes
# The binomial is a discrete distribution
# (you cannot have 1.5 heads from 10 tosses!)
# so this the Probability Mass Function (PMF,
# we use density for continuous functions: PDFs)
# 0 success to all successes
density <- dbinom(0:size, size, prob=0.5)

# the vaules here add up to exactly 1
sum(density)

# visualize the values 
plot(0:size,density, type="h" )

# A. experiment with setting size to 10, 100, 1000, 10000!
# As the number increases, the bell-shape will become smaller, but also smoother!
# As size approaches infinity, we approximate the Gaussian or Normal distribution.

# B. experiment with setting the probability something else, like 0.1!
# notice how the distribution's shape changes!
