# Readin in out mentally simulated coin flips.
# 2023-12-12

# working directory
setwd("/home/adam/Desktop/Rconsolidation/lecture9/coins/")

# Adam's coin flips
coins <- read.csv("coins.txt", header=FALSE)

# number of rows 
length(coins)
length(coins[,1])
length(coins$V1)

########################################----------------------------------------
# 1. Number of Tails:
# length - which - logical
length(which(coins$V1=="T"))

# sum -logical
sum(coins$V1=="T")

# both
table(coins$V1)

########################################----------------------------------------
# Artificially generating this
sample(c("T", "H"), 200, replace=TRUE)
sample(c("T", "H"), 200, replace=TRUE)
