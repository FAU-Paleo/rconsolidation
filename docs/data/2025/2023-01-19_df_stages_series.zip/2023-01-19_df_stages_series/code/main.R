wd <- "Z:/Unidesk/fau/rconsolidation/2023-01-19_df_stages_series"
setwd(wd)

# the files in the working directory
list.files()
list.files("data")

# much better to have it locally
stages <- read.csv("data/stages.csv")

# less preferable solution
stages <- read.csv("https://adamkocsis.github.io/rkheion/download/stages.csv")

# 3. Phanerozoic subset
# df-name[<rows>, <cols>] #2 Dimensional subscript
phanerozoic <- stages[which(stages$system!="Ediacaran"), ]

# Single dimensional numeric subscript
str(stages[1])
stages[2]
stages[length(stages)]

str(c(1,4,3,2))
str(c(1,4,3,2, "a"))

str(list(1,4,3,2, "a"))
str(list(1,4,1:3,2, "a", c(TRUE, FALSE)))
str(list(1,4,1:3,2, "a", c(TRUE, FALSE), list(1:5)))

str(stages)
# it still is a data.frame!
stages[3]

# 4. subset the phanerozoic object to the "Jurassic" system!
jurassic <- phanerozoic[which(phanerozoic$system=="Jurassic"), ]
length(unique(jurassic$series))


# the unique names of the phanerozoic periods
periods <- unique(phanerozoic$system)

################################################################################
# 5. For loop to calculate number of series in every system
# Homework

# a. Find the object that you to need use to 'guide' the for loop

# b. create a storage container where you can store the result
# of the computation

# c. actual iteration
# the definition of the loop
for(i in <guide>){
  
  # what is the calculation that you need to do in every iteration
  
  # store the result of that calculation
  
}



