wd <- "C:/Users/Adam/Desktop/rcourse/lecture2/2023-01-19_df_stages_series"
setwd(wd)

# the files in the working directory
list.files()
list.files("data")

# much better to have it locally
stages <- read.csv("data/stages.csv")

# less preferable solution
stages <- read.csv("https://adamkocsis.github.io/rkheion/download/stages.csv")

# 3. Phanerozoic subset
# df-name[<rows>, <cols>] #2 Dimensional subscript
phanerozoic <- stages[which(stages$system!="Ediacaran"), ]

# Single dimensional numeric subscript
str(stages[1])
stages[2]
stages[length(stages)]

# lists
str(c(1,4,3,2))
str(c(1,4,3,2, "a"))

str(list(1,4,3,2, "a"))
str(list(1,4,1:3,2, "a", c(TRUE, FALSE)))
str(list(1,4,1:3,2, "a", c(TRUE, FALSE), list(1:5)))

str(stages)
# it still is a data.frame!
stages[3]

# 4. subset the phanerozoic object to the "Jurassic" system!
jurassic <- phanerozoic[which(phanerozoic$system=="Jurassic"), ]
length(unique(jurassic$series))


# the unique names of the phanerozoic periods
periods <- unique(phanerozoic$system)

################################################################################
# 5. For loop to calculate number of series in every system
# Homework

# a. Find the object that you to need use to 'guide' the for loop
periods <- unique(phanerozoic$system)

# b. create a storage container where you can store the result
# of the computation
nSeries <- rep(NA, length(periods))
names(nSeries) <- periods

# c. actual iteration
# the definition of the loop
for(i in 1:length(periods)){
  
  # what is the calculation that you need to do in every iteration
  focalPeriod <- phanerozoic[which(phanerozoic$system==periods[i]), ]
 
  # store the result of that calculation
#  nSeries[i] <- length(unique(focalPeriod$series)) # numeric subscripts
  nSeries[periods[i]] <- length(unique(focalPeriod$series)) # character 
  
}

# Different (more functional way) to get to the same result.

# 1. Get a subset of the phanerozoic object, that only has two columns:
# system, series: (and every row)
# sysSer <- subset(phanerozoic, select=c(system, series))

# sysSer <- phanerozoic[,c(2,3)]
# phanerozoic$sys <- NULL

# Adam's preferred way
sysSer <- phanerozoic[,c("system","series")]

# get rid of duplicated rows
unSysSer <- unique(sysSer)
# tabulating the number of times the system occurrs in the table

# tells you how many series there are
tab <- table(unSysSer$system)

# you can always reord with character subscripts
tab[periods]

# in a single line of code
table(unique(phanerozoic[,c("system","series")])$system)



