# results to: https://adamtkocsis.com/rkheion/Exercises/2023-01-17_favia-occurrencecount.html

# Set working directory
setwd("C:/Users/Adam/Desktop/rcourse/lecture3/2023-01-17_favia-occurrencecount")

# 1-2. Dowload this file https://adamkocsis.github.io/rkheion/download/favia.csv
# and load into R!
favia <- read.csv("data/favia.csv")

# 3. Calculate the number of rows that are in a subset where
# the stg-value is 87. 
stg87 <- subset(favia, favia$stg==87)
stg87 <- favia[which(favia$stg==87), ]

# data frame length: is the number of variable
length(stg87)

# the number of rows
length(stg87$stg)
nrow(stg87)

# 4. calculate how many collections we have in the stg87 object!
length(unique(stg87$collection_no))

# 5. The stg numbers the taxon occurs in:
unique(favia$stg)

# sort allows you to sort this
stages <- sort(unique(favia$stg))

# count the number of occurrences (number of records) and 
# collections (number of unique records in collection_no column) in a stage

# 1. define a container/containers to store the information
nOccs <- rep(NA, length(stages))
names(nOccs) <- stages

# 2. for loop 1:length(stages)
for(i in seq_along(stages)){
  # message(stages[i])
  
  # grab the subset of the data where the stg column's value
  # is stages[i]
  stgDat <- favia[which(favia$stg==stages[i]), ]
  
  # calculate how many rows we have
  nOccs[i] <- nrow(stgDat)
  
}

# 2. Add new lines of code to calculate the the number of  
# collections (number of unique records in collection_no column) 
# in a stage. 

# 1. define a container/containers to store the information
nOccs <- rep(NA, length(stages))
names(nOccs) <- stages

# define a container where to store the results
nColls <- rep(NA, length(stages))
names(nColls) <- stages

# 2. for loop 1:length(stages)
for(i in seq_along(stages)){
  # message(stages[i])
  
  # grab the subset of the data where the stg column's value
  # is stages[i]
  stgDat <- favia[which(favia$stg==stages[i]), ]
  
  # calculate how many rows we have
  nOccs[i] <- nrow(stgDat)
  
  # number of unique collections in this stage
  stgCollNo <- length(unique(stgDat$collection_no))
  
  # store the calculated results
  nColls[i] <- stgCollNo
}


stgCollNo


# number of occurrences in a stage?
table(favia$stg)

# number of collections - with the table? 
# omit all information that does not represent the collection_no - stg
# relationship. Subset to two columns:
collStg <- favia[ , c("collection_no", "stg")]
unCollStg <- unique(collStg)
table(unCollStg$stg)


