# Solution to exercise with Sepkoski's compendium
# https://adamtkocsis.com/rkheion/Exercises/2024-02-05_sepkoski-mollusk.html
setwd("C:/Users/Adam/Desktop/rcourse/lecture8/2024-02-05_sepkoski-mollusk")

# 2. Read in the data into the global environment
sepkoski <- read.csv("data/sepkoski_kiessling_processed.csv", sep=";")

# 3. Mollusc subset
molluscs <- sepkoski[which(sepkoski$PHYLUM=="Mollusca"), ]
View(molluscs)

# the unique class entries inthe dataset
unique(molluscs$CLASS)
length(unique(molluscs$CLASS))

# 4. filter out the "Mollusca Inc. Sed." - omit rows where class is this
mollFiltered <- molluscs[which(molluscs$CLASS!="Mollusca Inc. Sed."), ]
# mollFiltered <- subset(molluscs, molluscs$CLASS!="Mollusca Inc. Sed.") # same as before

# a vector of all class names
classes <- unique(mollFiltered$CLASS)

# 5. Calculate durations of bivalves
# 5a. the duration column for the whole mollusc subset 
mollFiltered$duration <- mollFiltered$bot95_ma - mollFiltered$top95_ma

# 5b. Bivalve subset
bivalves <- mollFiltered[which(mollFiltered$CLASS=="Bivalvia"), ]

# 5c. calculate the mean 
mean(bivalves$duration, na.rm=TRUE)

# 6. The histogram
x11()
hist(bivalves$duration, breaks=20)

# 7. Calculate mean durations for all mollusc subsets
# iterations
durs <- rep(NA, length(classes))
names(durs) <- classes

# for loop
for(i in 1:length(classes)){
  
  #focalClass <- "Scaphopoda"
  focalClass <- classes[i]
  
  # subset to focal class
  focal <- mollFiltered[which(mollFiltered$CLASS==focalClass), ]
 
  # store the result 
  durs[i] <- mean(focal$duration, na.rm=TRUE)
}

# the result
durs

# 8. The class with the longest duration  
# only the value
max(durs)

# name and value
durs[which(durs==max(durs))]

# only the name
names(durs)[which(durs==max(durs))]
names(durs)[which.max(durs)]


