# results to: https://adamtkocsis.com/rkheion/Exercises/2023-01-17_favia-occurrencecount.html

# Set working directory
setwd("C:/Users/Adam/Desktop/rcourse/lecture2/favia")

# 1-2. Dowload this file https://adamkocsis.github.io/rkheion/download/favia.csv
# and load into R!
favia <- read.csv("data/favia.csv")

# 3. Calculate the number of rows that are in a subset where
# the stg-value is 87. 
stg87 <- subset(favia, favia$stg==87)
stg87 <- favia[which(favia$stg==87), ]

# data frame length: is the number of variable
length(stg87)

# the number of rows
length(stg87$stg)
nrow(stg87)

# 4. calculate how many collections we have in the stg87 object!
length(unique(stg87$collection_no))

# 5. The stg numbers the taxon occurs in:
unique(favia$stg)

# sort allows you to sort this
sort(unique(favia$stg))
