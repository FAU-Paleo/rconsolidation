# Solutions to 'The PaleoReefs Database'
# https://adamtkocsis.com/rkheion/Exercises/2025-02-03_pared_basics.html

# set a working directory
setwd("/mnt/sky/Dropbox/Teaching/FAU/RConsolidation/2024/pseudo_exam/2025-02-03_pared_basics/")
########################################----------------------------------------
# 1. Download daa
########################################----------------------------------------

########################################----------------------------------------
# 2. Reading in the data
########################################----------------------------------------
pared <- read.csv("data/pared_public.csv")
str(pared)

########################################----------------------------------------
# 3. Plotting a map of the occurrence records (NEEDS internet!)
########################################----------------------------------------
# if you need to install something
# install.packages(c("chronosphere", "sf"))
library(chronosphere)
ne <- chronosphere::fetch("NaturalEarth", verbose=FALSE)
plot(ne$geometry, col="gray", border=NA)

# the line you need to show the results
points(pared$LON, pared$LAT, col="red", pch=3)


########################################----------------------------------------
# 4. Tabulate the number of reefs per country
########################################----------------------------------------
tab <- table(pared$COUNTRY)

# which country has the highest number of reefs?
names(which.max(tab))


########################################----------------------------------------
# 5. Subset of the Cambrian system
########################################----------------------------------------
camb <- pared[which(pared$SYSTEM=="Cambrian"), ]

# tabulate occurrences by reef builders
reefBuilderTab <- table(camb$BIOTA.MAIN)

# all main reefs builders
builders <- names(reefBuilderTab)
builders[builders!=""] # clean vector

# most frequently: 
names(which.max(reefBuilderTab))


########################################----------------------------------------
# 6. Reefs where corals are the main reef builders
########################################----------------------------------------
corals <- pared[which(pared$BIOTA.MAIN=="Corals"), ]

########################################----------------------------------------
# 7. Jurassic coral reefs
########################################----------------------------------------
jur <- corals[which(corals$SYSTEM=="Jurassic"), ]

# number of coral reef sites
nrow(jur)

# median absolute paleolatitude
median(abs(jur$PALEO.LAT), na.rm=TRUE)


########################################----------------------------------------
# 8. Number of reefs + median absolute paleolatitude 
########################################----------------------------------------

# a guiding vector for the iteration
allSystems <- unique(corals$SYSTEM)

# create an empty container to store results
medianLats <- rep(NA, length(allSystems))
names(medianLats) <- allSystems

for(i in 1:length(allSystems)){
	# which system are we in?
	currentSystem <- allSystems[i]

	# subset of the data corresponding to this system
	systemData <- corals[which(corals$SYSTEM==currentSystem), ]

	# calculate median absolute paleolatitude and store it
	medianLats[i] <- median(abs(systemData$PALEO.LAT), na.rm=TRUE)

}


# the same with a tapply function call
# medianLats <- tapply(INDEX=corals$SYSTEM, X=corals$PALEO.LAT, FUN=function(x) median(abs(x), na.rm=TRUE))

# the correct order of these (no Cambrian coral reef!)
ord <- c(
	"Ordovician",
	"Silurian",
	"Devonian",
	"Carboniferous",
	"Permian",
	"Triassic" ,
	"Jurassic",
	"Cretaceous",
	"Paleogene",
	"Neogene",
	"Quarternary"
)

# the reordered version
reordered <- medianLats[ord]

plot(reordered, type="o", axes=FALSE)
axis(1, at=1:length(reordered), label=names(reordered))
axis(2)

# do they get closer to the equator since the Mesozoic? YES.
