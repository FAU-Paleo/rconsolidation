# Finishing exercise: Length of geologic periods
# https://adamtkocsis.com/rkheion/Exercises/2023-01-16_df_stages.html

# working diretory
setwd("C:/Users/Adam/Desktop/paleo_msc/semester_1/rconsolidation/lecture3/2023-01-16_df_stages")

# step 2
dat <-  read.csv("data/stages.csv")

# step 3: Mesozoic and Cenozoic subset
mAndC <- dat[which(dat$bottom < 253), ]

# step 4, in two subset
# step 4a. calculate durations for one system e.g. Triassic

# a subset for the Triassic
triassic <- mAndC[which(mAndC$system=="Triassic"),] 

# duraion of system: two different ways
# 1. bottom of system minus its top: max of the bottom column
# min of the top column: ?max
max(triassic$bottom)-min(triassic$top)

# 2. the sum of the durations of constituent stages
sum(triassic$dur)
# sum(1:5)


# step 4b. repeat the process for every system
# the systems for which we need to calculate everything
guide <- unique(mAndC$system)

# container to store the results, empty values
durations <- rep(NA, length(guide))

# definition of names: system
names(durations) <- guide

# define the iteration
for(i in 1:length(guide)){
  
  # focal system
  currentSystem <- guide[i]
  
  # subset of data
  system <- mAndC[which(mAndC$system == currentSystem),] 
  
  # calculate the durations
  durations[i] <- max(system$bottom)-min(system$top)

}

# step 5. histogram of the durations
hist(durations)


# histogram of the stage durations, with more breaks
histData <- hist(dat$dur, breaks=30)

# can be customized to have arbitrary breaks - not proper histogram anymore!
histData <- hist(dat$dur, breaks=c(0, 3, 10, 15, 100))

