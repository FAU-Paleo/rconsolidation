# Solution to: 2023-02-15_penguin_species.html

# 1. Download this file: penguins.csv
setwd("C:/Users/Adam/Desktop/paleo_msc/semester_1/rconsolidation/lecture8/2023-02-15_penguin_species")

# 2. Read it into R with read.csv()! Check its structure and familiarize yourself with the columns. Every row represents one observed penguin.
# import 
penguins <- read.csv("data/penguins.csv")

# 3. Subset the data to the the year 2009!
p2009 <- penguins[which(penguins$year==2009) , ]
  
# 4. List the species that were observed this year (every species name occurs once)!
species <- unique(p2009$species)

# 5. Select one species, e.g. the Gentoo, and subset the 2009 data to the corresponding part. Calculate the median body mass for this species. Hint: missing values can be omitted if you use median(x , na.rm=TRUE) where x is the input vector to the function.
p2009one <- p2009[which(p2009$species=="Gentoo"),]
median(p2009one$body_mass_g, na.rm=TRUE)

# 6. Repeat step 5 with a for() loop, calculate the median mass of every species.
# this is what was needed to repeat with  a for loop
p2009one <- p2009[which(p2009$species=="Chinstrap"),]
median(p2009one$body_mass_g, na.rm=TRUE)
p2009one <- p2009[which(p2009$species=="Adelie"),]
median(p2009one$body_mass_g, na.rm=TRUE)

# With an actual for loop

# 7 Plot a boxplot with adapting this code to your variable names (yearDat is the data.frame in my code):
