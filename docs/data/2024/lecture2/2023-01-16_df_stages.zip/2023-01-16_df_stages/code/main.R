# Solutions to exercise: 2023-01-16_df_stages (until step 3!)

# working directory
setwd("C:/Users/Adam/Desktop/paleo_msc/semester_1/rconsolidation/lecture2/2023-01-16_df_stages")

# file input
dat <- read.csv("data/stages.csv")

# check input!
View(dat)
str(dat)

#####################################################################
# Step. 3 - subset to mesozoic and cenozoic

# use bottom age and compare to a value 253
mAndC <- dat[which(dat$bottom<253), ]

# stg id greater or equal to 52
one <- dat[which(dat$stg>=52), ]

# based on row indices (less flexible)
two <- dat[52:nrow(dat),]

# The solution is giving you wrong results if the order changes!!!

#################################-----------------------------------
# Ordering things
vec <- c(3, 2, 5, 1, 2)

# returns the ordered vector
sort(vec)

# same with order: 
vec[order(vec)]

# the indices of values so the values will be returned in ascending order
order(vec)

# we can do this with a column of data.frame: for characters, this is 
# alphabetic sorting
sort(dat$stage)
order(dat$stage)

# alphabetically ordered single column
dat$stage[order(dat$stage)]
#################################-----------------------------------

# the whole data frame, ordered by stage names (equivalent data!)
ordered <- dat[order(dat$stage), ]

# subsetting with indices gives you wrong results
twoWrong <- ordered[52:nrow(ordered),]

# subsetting based on logical conditions will give you a correct result
mAndCOrdered <- ordered[which(ordered$bottom<253), ]

# %in% list of systems that we want - not efficient, typos, 
# also does not work well if the data.frame is large
three <- dat[
  dat$system %in% c("Triassic", "Jurassic", "Cretaceous", "Neogene", "Paleogene", "Quarternary") ,
]


