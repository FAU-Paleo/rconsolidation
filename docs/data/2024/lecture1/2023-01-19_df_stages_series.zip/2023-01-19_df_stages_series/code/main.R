# Solution script
# 2024-10-15

# list out the contents of the current working directory
list.files()

# path to the current working directory
getwd()


# Adam's working directory
# setwd("C:/Users/Adam/Desktop")

# adding interactive
# list.files()
# list.files("paleo_msc")
# list.files("paleo_msc/semester_1")
# list.files("paleo_msc/semester_1/rconsolidation")
# list.files("paleo_msc/semester_1/rconsolidation/lecture1")
# list.files("paleo_msc/semester_1/rconsolidation/lecture1/2023-01-19_df_stages_series")
# list.files("paleo_msc/semester_1/rconsolidation/lecture1/2023-01-19_df_stages_series/data")

# the location of the data file: reading in with absolute path
# dummy <- read.csv("C:/Users/Adam/Desktop/paleo_msc/semester_1/rconsolidation/lecture1/2023-01-19_df_stages_series/data/stages.csv")

# semantically more correct solution for the working directory - set this to your project directory!
# this is what Adam is using:
# setwd("/mnt/sky/Dropbox/Teaching/FAU/RConsolidation/2024/lecture1/2023-01-19_df_stages_series/")
# what we used in class
setwd("C:/Users/Adam/Desktop/paleo_msc/semester_1/rconsolidation/lecture1/2023-01-19_df_stages_series/")

# listing out  the contents of a specific directory
# list.files("C:/Users/Adam/Desktop/paleo_msc/semester_1/rconsolidation")


########################################----------------------------------------
# Step 2 - read in the file

# relative path to the file
filePath <- "data/stages.csv"

# reading in the file with read.csv!
dat <- read.csv(filePath)

# inspect the results!
str(dat)
View(dat)

########################################----------------------------------------
# Step 3

# Example that works with tibbles but not with data.frames!
# phanerozoic <- filter(dat, dat$system!="Ediacaran")

# matrix-style subsetting
phanerozoic <- dat[which(dat$system!="Ediacaran"), ]

# works, but not so good
# phanerozoic <- subset(dat, dat$system!="Ediacaran")

########################################----------------------------------------
# Step 4a: select the Jurassic subset!

# USE THE SAME OBJECT TO DO THE LOGICAL EVALUATION AND THE SUBSETTING
jurassic <- phanerozoic[which(phanerozoic$system=="Jurassic"), ]

# This example will lead not return an error, but it will produce wrong output!
# Very WROOONG you have to use the same object name twice in this idiom!
# jurassicWrong <- phanerozoic[which(dat$system=="Jurassic"), ]

# Using multiple systems, e.g. the Mesozoic?

# This is not the solution - actually, it is very WRONG.
#
# phanerozoic$system==c("Triassic", "Jurassic", "Cretaceous")
# garbage <- phanerozoic[which(phanerozoic$system==c("Triassic", "Jurassic", "Cretaceous")), ]
# # Check out
# View(garbage)
# # The right-hand side of the evaluation is recycled (repeated) as many times, as many values there are
# # on the left-hand side.
# HINT: if you do an evaluation with ==, then the two sides have to have the same length (pairwise)
# or one of the sides has to have the length of 1!

# Actual solution: match (%in%) operator
# the logical vector describing the correct rows
phanerozoic$system %in% c("Triassic", "Jurassic", "Cretaceous")

# Safest within which for subsetting
mesozoic <- phanerozoic[which(phanerozoic$system%in%c("Triassic", "Jurassic", "Cretaceous")), ]

# again, the solution to 4a:
# USE THE SAME OBJECT TO DO THE LOGICAL EVALUATION AND THE SUBSETTING
jurassic <- phanerozoic[which(phanerozoic$system=="Jurassic"), ]

# step 4b: count the number of series (epochs) in the Jurassic: a single number
length(unique(jurassic$series))

# Not in lecture: length(unique()) is a good friend - bu note that it will include missing values, because unique() does too!
unique(c(1,4, 3, 2, NA, NA,3, 6))

########################################----------------------------------------
# step 5: Get a complete of different systems/periods, 
# which should be a vector, where every item occurs only once. Solution: unique
listOfPeriods <- unique(phanerozoic$system)

########################################----------------------------------------
# step 6: Repeat step 4 with a for() loop, calculate the number of epochs in every period.

# Solution:

#1. copy the contents of step 4
jurassic <- phanerozoic[which(phanerozoic$system=="Jurassic"), ]
length(unique(jurassic$series))

# 2. rename objects to make them semantically correct and create a variable
# that controls the iteration
focalName <- "Jurassic"
focalSystem <- phanerozoic[which(phanerozoic$system==focalName), ]
length(unique(focalSystem$series))

# this results in exactly the same thing, but is now only dependent on focalName.

# 3. we need to define how we would like to iterate things. This is based on the listOfPeriods vector.
# We will iterate with the indices of this vector (1:length(listOfPeriods)). What we wrote becomes the body of the loop.

# the iteration
for(i in 1:length(listOfPeriods)){
	# which system do we want
	focalName <- "Jurassic"

	# get the corresponding data
	focalSystem <- phanerozoic[which(phanerozoic$system==focalName), ]

	# and the number of series in the system
	length(unique(focalSystem$series))
}


# NOTE: you have to make sure that focalName never becomes a missing value - i.e. that listOfPeriods does not have one!

# 4. Our iteration does not do anything different until we make one of the variables dependent on i.
# we have set up our loop so we can get the ith element of listOfPeriods to define focalName.
# Also without seeing some result, we cannot be sure that we have been working correctly.
# Always feel free to add message()s to your loop. These can be commented out or reused later!

# the iteration
for(i in 1:length(listOfPeriods)){
	# which system do we want
	focalName <- listOfPeriods[i]
	message(focalName)

	# get the corresponding data
	focalSystem <- phanerozoic[which(phanerozoic$system==focalName), ]

	# and the number of series in the system
	message(length(unique(focalSystem$series)))
}

# HINT: you can always debug a loop by assigning values to i manually, like:
i<- 7
# then you can inspect what the loop is doing in the 7th iteration cycle if you run the code manually.


# 5. now we need to save our data. Since there is exactly one value produced for every system
# we can reserve some space to hold our results. This will need to have as many values as many
# we have in the listOfPeriods object. Initializing this with missing values is good practice,
# because this way you will see whether alignments are perfect or not. We also have to store
# our results instead of displaying them in messages. This can be done by replacing the ith
# value in our container with the number of series in every iteration.


# the container to store the results
container <- rep(NA,length(listOfPeriods))

for(i in 1:length(listOfPeriods)){
	# which system do we want
	focalName <- listOfPeriods[i]
	message(focalName)

	# get the corresponding data
	focalSystem <- phanerozoic[which(phanerozoic$system==focalName), ]

	# and the number of series in the system
	container[i] <- length(unique(focalSystem$series))
}

container

# 6. We are almost done! We still need to find a way to make sure that the alignment
# between the names and the number of series is unambiguous. This we can do by assigning
# names to the values in container. These names are going to be the system names.

# the container to store the results
container <- rep(NA,length(listOfPeriods))
names(container) <- listOfPeriods

for(i in 1:length(listOfPeriods)){
	# which system do we want
	focalName <- listOfPeriods[i]
	# message(focalName)

	# get the corresponding data
	focalSystem <- phanerozoic[which(phanerozoic$system==focalName), ]

	# and the number of series in the system
	container[i] <- length(unique(focalSystem$series))
}

container


# And we are done! Always do some sanity checks on your results - if you have time/energy
# and you don't have that much data, pick results randomly (in the middle) and see if you
# arrive at the same result using a different method. It is also a good idea to check
# the corner cases (first and last cycle) and where you suspect that the code might
# not work as intended!


# step 7. A simpler way of doing the same thing is to change the 'nature' of the
# table. In the original <phanerozoic> object, every row represents a stage.
# If we select columns that include redundant information for a higher-level unit,
# then we can change the table's primary entity to something: for instance, we can make it
# a series-level table (this is a type of data normalization):

# series-specific information
seriesInfo<- phanerozoic[, c("system", "series")]

# omit duplicates with unique (when applied to data.frames, it will omit rows that) are
# have combinations of data that have already occurred.
seriesTable <- unique(seriesInfo)

# this can be done in a single line of code
seriesTable <- unique(phanerozoic[, c("system", "series")])

# in this table, every row represents one series. If we tabulate the number of
# times when a system is appearing in this table, that will tell us how many
# series there are in a system
table(seriesTable$system)

# note that this output has a different order! Table will sort the names
# alphabetically.
