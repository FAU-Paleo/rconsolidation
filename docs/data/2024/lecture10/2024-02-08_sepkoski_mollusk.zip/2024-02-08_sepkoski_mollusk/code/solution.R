# Solution for https://adamtkocsis.com/rkheion/Exercises/2024-02-05_sepkoski-mollusk.html

# set working directory
setwd("/mnt/sky/Dropbox/Teaching/FAU/RConsolidation/2023/pseudoexam/2024-02-08_sepkoski_mollusk/")

# 2. you need the sep=";" becuase the data are semicolon separated!
sep <- read.csv("data/sepkoski_kiessling_processed.csv", sep=";")
str(sep)


# 3. Subset to the molluscs
moll <- sep[which(sep$PHYLUM=="Mollusca"), ]

# all the classes - clarifiy
unique(moll$CLASS)

# the number of class entries
length(unique(moll$CLASS))


# 4. This is an invalid class name
moll2 <- moll[which(moll$CLASS!="Mollusca Inc. Sed."), ]
unique(moll2$CLASS)

# 5.  the durations of the molluscs
moll2$duration <- moll2$bot95_ma - moll2$top95_ma

# The bivalve subset
biv <- moll2[which(moll2$CLASS=="Bivalvia"), ]

# explain missing durations
mean(biv$duration, na.rm=TRUE)

# 6. The histogram of the bivalve durations
# This is right-skewed distribution. Most bivalves short durations, which actually is a general pattern!
hist(biv$duration)


# 7. The molluscs
# all the mollusc classes agagin
mollClass <- unique(moll2$CLASS)

# container to store the class-specific results
classDurs <- rep(NA, length(mollClass))
names(classDurs) <- mollClass

# repeate for the index values of the class names
for(i in 1:length(classDurs)){
	# select a focal class
	focal <- moll2[which(moll2$CLASS==mollClass[i]), ]

	# some durations have missing values, becuase of timescale
	# you have to use na.rm=TRUE for these
	classDurs[i] <- mean(focal$duration, na.rm=TRUE)

}
# the durations of the classes
classDurs

# which class has the longest duration?
names(classDurs)[max(classDurs)==classDurs]
