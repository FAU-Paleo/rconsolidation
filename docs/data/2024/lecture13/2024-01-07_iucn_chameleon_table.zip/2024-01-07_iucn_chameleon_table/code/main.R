# Solution to the exercise: IUCN Chameleon Data

# https://adamtkocsis.com/rkheion/Exercises/2024-01-07_iucn_chameleon_table.html

# 1. Download this file: chameleons.csv. This includes some data from an older subset of this dataset (without the spatial data on the ranges themselves).
setwd("/mnt/sky/Dropbox/Teaching/FAU/RConsolidation/2024/lecture13/2024-01-07_iucn_chameleon_table")

# 2. Read it into R with read.csv()! Check its structure and ensure that the dataset has been read in correctly (remember to adjust the sep argument if necessary!). Every row should represent a range assessment of one species. There are multiple records of a species, when the species was assessed in multiple years. First, we need to know how many taxa there are in this dataset.
cham <- read.csv("data/chameleons.csv", sep=";")

# 3. Create a subset of the data.frame, which has only the "genus" and "binomial" columns. Omit the duplicates! Use this subset for points 4. and 5.!
genBin <- cham[, c("genus", "binomial")]
genBin <- unique(genBin)

# 4. How many chameleon species and genera are there in the dataset? (two numbers, one for species, one for genera)
length(unique(genBin$binomial))
length(unique(genBin$genus)) # maintain original order

length(levels(factor(genBin$genus))) # sorted


# 5. Which genus has the highest number of species? (character string)
tab <- table(genBin$genus)
names(which.max(tab))
names(which(max(tab)==tab))

# 6. Using the original dataset, make a scatterplot using the "SHAPE_Area" and "SHAPE_Leng" variables (columns). These columns indicate the total area and length (maximum extent in one direction) of the species’ distributions. Make a scatterplot of the two variables! Are the two variables correlated? (a plot, and test)
plot(cham$SHAPE_Leng, cham$SHAPE_Area, xlab="Length", ylab="Area")
cor(cham$SHAPE_Leng, cham$SHAPE_Area)
cor.test(cham$SHAPE_Leng, cham$SHAPE_Area)

# 7. For the remainder of the exercise, we need to omit duplicate entries for the species. We can do this by omitting every assessment record but the most recent one (timestamp is yrcompiled column), which can be implemented simply with:

# if your data.frame read in in point 2 is called 'chameleons'
chamReord <- cham[order(cham$binomial, cham$yrcompiled, decreasing=TRUE),]
chamFiltered <- chamReord[!duplicated(chamReord$binomial), ]

# What is happening in this chunk of code? Make sure that you use these results for points 8 - 10!

# 8. The IUCN assigns species into categories of conservation status (see them here). These assessments are in the category column. Create a subset for the Vulnerable "VU" category, and count the number of species in this category. Also calculate the median area (SHAPE_Area) for the category. (Using the median() function) (two numbers, an integer and floating point number)
vulnerable <- chamFiltered[which(chamFiltered$category=="VU"),]
nrow(vulnerable)
median(vulnerable$SHAPE_Area)

# 9. Calculate the median shape area for all assessment categories! You can do this with a for loop that repeats the calculation in point 7 on every category in the dataset! (a numeric vector with categories in the names)
categ <-  unique(chamFiltered$category)

# median areas
areas <- rep(NA, length(categ))
names(areas) <- categ

# the number of species per category
species <- rep(NA, length(categ))
names(species) <- categ

# repeat for every element of categ
for(i in 1:length(categ)){

	# the current element, i.e. list category
	focusCateg <- categ[i]

	# sselect the dataset
	focusDat <- chamFiltered[which(chamFiltered$category==focusCateg),]

	# the number of rows, ie..e the number of species
	species[i] <- nrow(focusDat)

	# the median area
	areas[i] <- median(focusDat$SHAPE_Area)
}

# 10. Which category has the highest median geographic range? (a category name, character string)
names(which.max(areas))


################################################################################
# Extra challenge
################################################################################

# Step 8 can be written without a for loop. Do you know how to do it?
# the number of categories
table(chamFiltered$category)

# Table-apply: INDEX describes a pattern, usually rows in a table that belong together in a category
# X is a vector (i.e. column) on which a procedure is to be repeated
# FUN is the function (procedure) that needs to be repeated on a subset of X - that subset that corresponds
# the values of INDEX
# this is oredered!
tapply(INDEX=chamFiltered$category, X=chamFiltered$SHAPE_Area, median)

# same as (ordered alphabetically)
areas[sort(categ)]

# Step 6 is an example of a beautiful power-law relationship between length and area. Make a log-log plot to show it! Can you construct a linear model with the logged data?

# simple log-log plot
plot(cham$SHAPE_Leng, cham$SHAPE_Area, xlab="Length", ylab="Area", log="xy")

# the base of the logarithm does not matter
# the logarithm can be calculated before the plotting
plot(log(cham$SHAPE_Leng), log(cham$SHAPE_Area), xlab="log Length", ylab="log Area")

# these can be used in a linear model

# create new columns
cham$logLength <- log(cham$SHAPE_Leng)
cham$logArea <- log(cham$SHAPE_Area)

# linear regression
mod <- lm(logArea ~ logLength, data=cham)

# visualize (on previous plot)
abline(mod)

# overview
mod

# summary
summary(mod)

# the slope of this line is the exponent of the power relationship (should be around 2)
