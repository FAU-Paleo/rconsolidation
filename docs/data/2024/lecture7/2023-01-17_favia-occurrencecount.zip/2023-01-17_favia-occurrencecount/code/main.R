# Solution to : https://adamtkocsis.com/rkheion/Exercises/2023-01-17_favia-occurrencecount.html

# working directory
setwd("C:/Users/Adam/Desktop/paleo_msc/semester_1/rconsolidation/lecture7/2023-01-17_favia-occurrencecount")

# 1. Download the occurrence file: favia.csv

# 2. Read it into R with read.csv()!
favia <- read.csv("data/favia.csv")
  
# 3. Calculate how many occurrences (rows in the table) the genus has where the 
#    stg (stage) column’s value is 87! This indicates Priabonian (Eocene) stage. 
#   This should be a single numeric value.
sum(favia$stg == 87)
length(which(favia$stg == 87))


# 4. Calculate how many different collections (entries in the collection_no column) 
#    there are in this stage! This should be a single numeric value.
priabonian <- favia[ which(favia$stg == 87) , ]

# the number of collections
length(unique(priabonian$collection_no))
length(table(favia[ which(favia$stg == 87) , "collection_no"]))

# 5. Calculate which stg numbers does this genus occur in! This should be a 
#    numeric vector.
bins <- sort(unique(favia$stg))
as.numeric(names(table(favia$stg)))

# 6. Calculate the number of occurrences and collections in every stage! These
#    should be two numeric vectors. Please indicate which stages the values in 
#    these vectors refer to by adding the stg numbers as the names attribute!

# Create containers to hold the data
occs <- rep(NA, length(bins))
colls <- rep(NA, length(bins))
names(occs) <- bins
names(colls) <- bins

# repeat for every sampled time bin
for(i in 1:length(bins)){

  s <- bins[i]
  
  # number of occurrences
  occs[i] <- sum(favia$stg == s)
  
  # number of collections
  currentStage <- favia[ which(favia$stg == s) , ]
  colls[i] <- length(unique(currentStage$collection_no))

}

# this is the same as occs
table(favia$stg)
